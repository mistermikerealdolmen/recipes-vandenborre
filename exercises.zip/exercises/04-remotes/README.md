This exercise will use the Git repository available here: https://github.com/kvanrobbroeck/git-course-recipes

A local version of this repository is bundled here when using GitHub is not possible. You will require a working internet connection and a remote server to work with to be able to do these exercises though.